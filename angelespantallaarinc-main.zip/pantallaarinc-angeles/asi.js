const canvas = document.getElementById("asi");
const ctx = canvas.getContext("2d");
const slider = document.getElementById("speed");
const valor = document.getElementById("valor");

const cx = 200, cy = 200, radius = 150;
let speed = 0;
const maxSpeed = 200;

function spdToAngle(v) {
  return (225 - (v / maxSpeed) * 270) * Math.PI / 180;
}

function arcoColor(inicio, fin, color) {
  ctx.beginPath();
  ctx.arc(cx, cy, radius - 20, spdToAngle(inicio), spdToAngle(fin), true);
  ctx.strokeStyle = color;
  ctx.lineWidth = 15;
  ctx.stroke();
}

function drawASI(v) {
  ctx.clearRect(0, 0, canvas.width, canvas.height);

  // Dial negro
  const grad = ctx.createRadialGradient(cx, cy, 50, cx, cy, 150);
  grad.addColorStop(0, "#111");
  grad.addColorStop(1, "#000");
  ctx.fillStyle = grad;
  ctx.beginPath();
  ctx.arc(cx, cy, radius, 0, 2 * Math.PI);
  ctx.fill();

  // Bandas de color
  arcoColor(40, 85, "white");
  arcoColor(50, 130, "green");
  arcoColor(130, 160, "yellow");
  arcoColor(160, 200, "red");

  // Marcas y números
  ctx.strokeStyle = "white";
  ctx.lineWidth = 2;
  for (let i = 0; i <= maxSpeed; i += 10) {
    const ang = spdToAngle(i);
    const x1 = cx + Math.cos(ang) * (radius - 25);
    const y1 = cy - Math.sin(ang) * (radius - 25);
    const x2 = cx + Math.cos(ang) * (radius - (i % 20 === 0 ? 40 : 35));
    const y2 = cy - Math.sin(ang) * (radius - (i % 20 === 0 ? 40 : 35));
    ctx.beginPath();
    ctx.moveTo(x1, y1);
    ctx.lineTo(x2, y2);
    ctx.stroke();

    if (i % 20 === 0) {
      const tx = cx + Math.cos(ang) * (radius - 60);
      const ty = cy - Math.sin(ang) * (radius - 60);
      ctx.font = "16px Arial";
      ctx.fillStyle = "white";
      ctx.textAlign = "center";
      ctx.textBaseline = "middle";
      ctx.fillText(i, tx, ty);
    }
  }

  // Etiqueta “KIAS”
  ctx.font = "18px Roboto";
  ctx.fillStyle = "white";
  ctx.fillText("KIAS", cx, cy + 60);

  // Aguja
  const ang = spdToAngle(v);
  ctx.save();
  ctx.translate(cx, cy);
  ctx.rotate(-ang);
  ctx.beginPath();
  ctx.moveTo(-5, 0);
  ctx.lineTo(100, 0);
  ctx.strokeStyle = "red";
  ctx.lineWidth = 3;
  ctx.stroke();
  ctx.restore();

  // Centro
  ctx.beginPath();
  ctx.arc(cx, cy, 8, 0, 2 * Math.PI);
  ctx.fillStyle = "silver";
  ctx.fill();

  valor.textContent = `${v} KIAS`;
}

slider.addEventListener("input", e => {
  speed = Number(e.target.value);
  drawASI(speed);
});

drawASI(speed);
